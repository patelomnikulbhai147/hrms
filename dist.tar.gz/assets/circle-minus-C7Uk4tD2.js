import{c}from"./index-BFuc6v6d.js";const e=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M8 12h8",key:"1wcyev"}]],o=c("circle-minus",e);export{o as C};
