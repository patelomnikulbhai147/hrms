import{a as k,j as t}from"./vendor-motion-DP_96VFI.js";const B=`
.zh-viz {
  --viz-grid: #E2E8F0;
  --viz-axis: #94A3B8;
  --viz-ink: #0F172A;
  --viz-ink-muted: #64748B;
  --viz-surface: #FFFFFF;
  --viz-bar: #B5673A;
  --viz-bar-hover: #99552F;
  --viz-s1: #2a78d6;
  --viz-s2: #eb6834;
  --viz-s3: #1baf7a;
  --viz-s4: #eda100;
  --viz-s5: #e87ba4;
  --viz-s6: #4a3aa7;
}
:root:not([data-theme="light"]) .zh-viz {
  --viz-grid: #2B3245;
  --viz-axis: #64748B;
  --viz-ink: #F8FAFC;
  --viz-ink-muted: #94A3B8;
  --viz-surface: #1D2230;
  --viz-bar: #E0996A;
  --viz-bar-hover: #F0CBAE;
  --viz-s1: #3987e5;
  --viz-s2: #d95926;
  --viz-s3: #199e70;
  --viz-s4: #c98500;
  --viz-s5: #d55181;
  --viz-s6: #9085e9;
}
`,E=["var(--viz-s1)","var(--viz-s2)","var(--viz-s3)","var(--viz-s4)","var(--viz-s5)","var(--viz-s6)"],S=()=>(k.useEffect(()=>{const e="zh-viz-tokens";if(document.getElementById(e))return;const n=document.createElement("style");n.id=e,n.textContent=B,document.head.appendChild(n)},[]),null);function D(){const e=k.useRef(null),[n,r]=k.useState(0);return k.useEffect(()=>{const a=e.current;if(!a)return;const o=new ResizeObserver(i=>r(i[0].contentRect.width));return o.observe(a),r(a.clientWidth),()=>o.disconnect()},[]),[e,n]}const P=({x:e,y:n,title:r,value:a,sub:o,w:i})=>{const x=Math.max(4,Math.min(e,i-150));return t.jsxs("div",{className:"pointer-events-none absolute z-20 rounded-xl border border-hairline bg-surface shadow-card px-3 py-2 min-w-[120px]",style:{left:x,top:Math.max(0,n-8),transform:"translate(-50%, -100%)"},children:[t.jsx("div",{className:"text-[11px] font-semibold text-ink-muted uppercase tracking-wide",children:r}),t.jsx("div",{className:"text-[14px] font-bold text-ink tabular-nums mt-0.5",children:a}),o&&t.jsx("div",{className:"text-[11px] text-ink-muted mt-0.5",children:o})]})};function W(e,n,r,a,o=4){const i=Math.max(0,Math.min(o,r/2,a));return a<=0?"":`M${e},${n+a} L${e},${n+i} Q${e},${n} ${e+i},${n} L${e+r-i},${n} Q${e+r},${n} ${e+r},${n+i} L${e+r},${n+a} Z`}function C(e){if(e<=0)return 1;const n=Math.pow(10,Math.floor(Math.log10(e))),r=e/n;return(r<=1?1:r<=2?2:r<=2.5?2.5:r<=5?5:10)*n}const _=({data:e,height:n=240,format:r,tickFormat:a,emptyLabel:o="No data for this period yet."})=>{const[i,x]=D(),[c,y]=k.useState(null),b=a||r;if(!e.length)return t.jsx("div",{className:"py-14 text-center text-[13px] text-ink-muted font-medium",children:o});const v=52,f=8,m=12,g=26,d=Math.max(x,280),$=Math.max(10,d-v-f),s=Math.max(10,n-m-g),l=C(Math.max(...e.map(u=>u.value),0)),h=$/e.length,j=Math.max(6,Math.min(44,h-12)),M=[0,.25,.5,.75,1].map(u=>u*l),w=e.reduce((u,p,z)=>p.value>e[u].value?z:u,0);return t.jsxs("div",{className:"zh-viz relative",ref:i,children:[t.jsx(S,{}),t.jsxs("svg",{width:d,height:n,role:"img","aria-label":"Bar chart",style:{display:"block"},children:[M.map((u,p)=>{const z=m+s-u/l*s;return t.jsxs("g",{children:[t.jsx("line",{x1:v,x2:d-f,y1:z,y2:z,stroke:"var(--viz-grid)",strokeWidth:1}),t.jsx("text",{x:v-8,y:z+3.5,textAnchor:"end",fontSize:10.5,fill:"var(--viz-ink-muted)",style:{fontVariantNumeric:"tabular-nums"},children:b(u)})]},p)}),e.map((u,p)=>{const z=l>0?u.value/l*s:0,N=v+p*h+(h-j)/2,A=m+s-z,F=c===p;return t.jsxs("g",{children:[t.jsx("rect",{x:v+p*h,y:m,width:h,height:s,fill:"transparent",onMouseEnter:()=>y(p),onMouseLeave:()=>y(null)}),t.jsx("path",{d:W(N,A,j,z),fill:F?"var(--viz-bar-hover)":"var(--viz-bar)",style:{transition:"fill .15s"},pointerEvents:"none"}),p===w&&z>14&&t.jsx("text",{x:N+j/2,y:A-5,textAnchor:"middle",fontSize:10.5,fontWeight:700,fill:"var(--viz-ink)",pointerEvents:"none",style:{fontVariantNumeric:"tabular-nums"},children:b(u.value)}),t.jsx("text",{x:N+j/2,y:n-8,textAnchor:"middle",fontSize:10.5,fill:"var(--viz-ink-muted)",pointerEvents:"none",children:u.label})]},u.key)}),t.jsx("line",{x1:v,x2:d-f,y1:m+s,y2:m+s,stroke:"var(--viz-axis)",strokeWidth:1})]}),c!==null&&t.jsx(P,{w:d,x:v+c*h+h/2,y:m+s-(l>0?e[c].value/l*s:0),title:e[c].label,value:r(e[c].value),sub:e[c].sub})]})};function L(e,n,r,a,o,i){const x=(s,l)=>[e+s*Math.cos(l),n+s*Math.sin(l)],c=i-o>Math.PI?1:0,[y,b]=x(r,o),[v,f]=x(r,i),[m,g]=x(a,i),[d,$]=x(a,o);return`M${y},${b} A${r},${r} 0 ${c} 1 ${v},${f} L${m},${g} A${a},${a} 0 ${c} 0 ${d},${$} Z`}const I=({data:e,size:n=190,centerLabel:r,centerValue:a,emptyLabel:o="Nothing to show yet."})=>{const[i,x]=k.useState(null),c=e.reduce((s,l)=>s+(Number(l.value)||0),0),y=k.useCallback(s=>E[s%E.length],[]);if(!c)return t.jsx("div",{className:"py-14 text-center text-[13px] text-ink-muted font-medium",children:o});const b=n/2,v=n/2,f=n/2-2,m=f-26,g=2/((f+m)/2);let d=-Math.PI/2;const $=e.map((s,l)=>{const h=(Number(s.value)||0)/c*Math.PI*2,j=d+g/2,M=d+h-g/2;return d+=h,{d:s,i:l,path:M>j?L(b,v,f,m,j,M):""}});return t.jsxs("div",{className:"zh-viz flex flex-col sm:flex-row items-center gap-6",children:[t.jsx(S,{}),t.jsx("div",{className:"relative flex-shrink-0",children:t.jsxs("svg",{width:n,height:n,role:"img","aria-label":"Distribution donut chart",children:[$.map(({d:s,i:l,path:h})=>h&&t.jsx("path",{d:h,fill:y(l),opacity:i===null||i===l?1:.45,style:{transition:"opacity .15s"},onMouseEnter:()=>x(l),onMouseLeave:()=>x(null)},s.key)),t.jsx("text",{x:b,y:v-2,textAnchor:"middle",fontSize:22,fontWeight:700,fill:"var(--viz-ink)",children:String(i===null?a:e[i].value)}),t.jsx("text",{x:b,y:v+15,textAnchor:"middle",fontSize:10,fill:"var(--viz-ink-muted)",style:{textTransform:"uppercase",letterSpacing:".06em"},children:i===null?r:e[i].label})]})}),t.jsx("ul",{className:"flex-1 w-full space-y-1.5 min-w-0",children:e.map((s,l)=>t.jsxs("li",{onMouseEnter:()=>x(l),onMouseLeave:()=>x(null),className:"flex items-center gap-2.5 px-2 py-1.5 rounded-lg hover:bg-surface-muted transition-colors",children:[t.jsx("span",{className:"h-2.5 w-2.5 rounded-sm flex-shrink-0",style:{backgroundColor:y(l)}}),t.jsx("span",{className:"text-[13px] text-ink-secondary font-medium truncate flex-1",children:s.label}),t.jsx("span",{className:"text-[13px] font-bold text-ink tabular-nums",children:s.value}),t.jsxs("span",{className:"text-[11.5px] text-ink-muted tabular-nums w-10 text-right",children:[c?Math.round(s.value/c*100):0,"%"]})]},s.key))})]})};export{_ as B,I as D};
