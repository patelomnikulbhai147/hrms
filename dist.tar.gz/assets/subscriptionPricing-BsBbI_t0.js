const n=e=>"₹"+(Number(e)||0).toLocaleString("en-IN");export{n as i};
