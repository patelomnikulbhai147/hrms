import{c as o}from"./index-B6Zg0fBr.js";const c=[["path",{d:"M5 12h14",key:"1ays0h"}]],e=o("minus",c);export{e as M};
