# Flutter Models: Attendance & Leave

## 1. Attendance Model

```dart
class Attendance {
  final int id;
  final int companyId;
  final int employeeId;
  final String employeeName;
  final String department;
  final String? branch;
  final String date;
  final String clockIn;
  final String clockOut;
  final String status;
  final double hoursWorked;

  Attendance({
    required this.id,
    required this.companyId,
    required this.employeeId,
    required this.employeeName,
    required this.department,
    this.branch,
    required this.date,
    required this.clockIn,
    required this.clockOut,
    required this.status,
    required this.hoursWorked,
  });

  factory Attendance.fromJson(Map<String, dynamic> json) {
    return Attendance(
      id: json['id'],
      companyId: json['companyId'],
      employeeId: json['employeeId'],
      employeeName: json['employeeName'] ?? 'Unknown',
      department: json['department'] ?? 'General',
      branch: json['branch'],
      date: json['date'],
      clockIn: json['clockIn'] ?? '',
      clockOut: json['clockOut'] ?? '',
      status: json['status'] ?? 'Present',
      hoursWorked: (json['hoursWorked'] ?? 0).toDouble(),
    );
  }
}
```

## 2. Leave Request Model

```dart
class LeaveRequest {
  final int id;
  final int companyId;
  final int employeeId;
  final String employeeName;
  final String leaveType;
  final String fromDate;
  final String toDate;
  final double days;
  final String reason;
  final String status;
  final String appliedOn;

  LeaveRequest({
    required this.id,
    required this.companyId,
    required this.employeeId,
    required this.employeeName,
    required this.leaveType,
    required this.fromDate,
    required this.toDate,
    required this.days,
    required this.reason,
    required this.status,
    required this.appliedOn,
  });

  factory LeaveRequest.fromJson(Map<String, dynamic> json) {
    return LeaveRequest(
      id: json['id'],
      companyId: json['companyId'],
      employeeId: json['employeeId'],
      employeeName: json['employeeName'],
      leaveType: json['leaveType'],
      fromDate: json['fromDate'],
      toDate: json['toDate'],
      days: (json['days'] ?? 0).toDouble(),
      reason: json['reason'],
      status: json['status'],
      appliedOn: json['appliedOn'],
    );
  }
}
```

## 3. Leave Balance Model

```dart
class LeaveBalance {
  final double cl;
  final double pl;
  final double sl;
  final int year;

  LeaveBalance({
    required this.cl,
    required this.pl,
    required this.sl,
    required this.year,
  });

  factory LeaveBalance.fromJson(Map<String, dynamic> json) {
    return LeaveBalance(
      cl: (json['cl'] ?? 0).toDouble(),
      pl: (json['pl'] ?? 0).toDouble(),
      sl: (json['sl'] ?? 0).toDouble(),
      year: json['year'] ?? DateTime.now().year,
    );
  }
}
```
